//
//  MSPortfolioItem.swift
//  MockStock
//
//  Created by Theodore Hecht on 3/11/19.
//  Copyright © 2019 Theodore Hecht. All rights reserved.
//

import Foundation

class MSPortfolioItem {
    var symbol = ""
    var price = 0.0
    var quantity = 0
    var percentChange = 0.0
}
