//
//  MSMarketPlaceItem.swift
//  MockStock
//
//  Created by Luke Orr on 3/27/19.
//  Copyright © 2019 Theodore Hecht. All rights reserved.
//

import Foundation
import UIKit

class MSMarketPlaceItem{
    var symbol = ""
    var price = 0.0
    var imageName = ""
    var percent = 0.0
}
