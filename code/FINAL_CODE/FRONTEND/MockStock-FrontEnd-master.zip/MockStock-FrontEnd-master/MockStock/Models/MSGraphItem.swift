//
//  MSGraphItem.swift
//  MockStock
//
//  Created by Luke Orr on 4/7/19.
//  Copyright © 2019 Theodore Hecht. All rights reserved.
//

import Foundation


class MSGraphItemPrice{
    var closingPrice = 0.0
}
class MSGraphItemDate{
     var date = ""
}
