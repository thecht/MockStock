# MockStock-FrontEnd
The iOS frontend app for the Mock Stock project.
