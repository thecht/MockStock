# MockStock-Backend
The backend for the mock stock app
